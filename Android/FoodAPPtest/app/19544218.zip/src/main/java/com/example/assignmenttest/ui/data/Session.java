package com.example.assignmenttest.ui.data;

import java.util.ArrayList;

public class Session {
    public static int USER;
    public static String thisFragment;

    //public static long orderNo_previous; //previous order number
    public static long orderNo_current; //current order number
    public static float order_total_cost;
    public static long basket_id;
    //public static ArrayList<String> items;

    public static int food_id;
    public static float food_price;
    public static int quantity_add; //for transferring of quantity between fragments
}
