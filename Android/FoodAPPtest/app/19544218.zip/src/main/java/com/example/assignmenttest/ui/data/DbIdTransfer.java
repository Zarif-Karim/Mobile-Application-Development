package com.example.assignmenttest.ui.data;

public class DbIdTransfer {
    public static int restaurant, user, food, orders, basket;
}
