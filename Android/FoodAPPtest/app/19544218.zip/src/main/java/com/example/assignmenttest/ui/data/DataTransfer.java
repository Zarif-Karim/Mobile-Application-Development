package com.example.assignmenttest.ui.data;

public class DataTransfer {
    public static int id;
    public static CharSequence name;
    public static CharSequence style;
    public static CharSequence location;
    public static float minOrder;
}
