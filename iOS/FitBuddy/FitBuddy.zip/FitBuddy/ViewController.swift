//
//  ViewController.swift
//  FitBuddy
//
//  Created by Muhsana Chowdhury  on 20/1/21.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var g: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

}

